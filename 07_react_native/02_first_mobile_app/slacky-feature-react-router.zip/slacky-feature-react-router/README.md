# Slacky

Start with `npm install` to get all packages

To launch this app, you will need two terminals

Launch the Websocket server with :

```
node server/server.js
```

Launch the React App with

```
npm start
```
